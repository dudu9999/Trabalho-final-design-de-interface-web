$( function() {
  $( "#datepicker" ).datepicker();
} );
